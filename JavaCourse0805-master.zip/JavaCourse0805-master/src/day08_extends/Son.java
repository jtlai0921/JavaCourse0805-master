package day08_extends;

public class Son extends Father {

    @Override
    public void play() {
        System.out.println("LoL");
    }
   
}
