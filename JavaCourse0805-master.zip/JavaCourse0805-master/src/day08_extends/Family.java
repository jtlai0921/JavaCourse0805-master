package day08_extends;

public class Family {
    public static void main(String[] args) {
        Son son = new Son();
        son.play();
    }
}
