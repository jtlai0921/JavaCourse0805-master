package day08_extends;

public class Father {
    public void play() {
        System.out.println("Golf");
    }
}
