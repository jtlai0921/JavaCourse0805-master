package day10_lambda_2;

public interface Plus {
    Salary get(double x);
}
