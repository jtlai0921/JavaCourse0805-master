package day10_lambda_2;

public interface Salary {
   double get(double y); 
}
