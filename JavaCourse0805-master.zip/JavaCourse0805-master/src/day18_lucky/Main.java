package day18_lucky;

public class Main {
    public static void main(String[] args) {
        Lucky777 lucky1 = new Lucky777("小明");
        Lucky777 lucky2 = new Lucky777("小華");
        lucky1.start();
        lucky2.start();
        
    }
}
