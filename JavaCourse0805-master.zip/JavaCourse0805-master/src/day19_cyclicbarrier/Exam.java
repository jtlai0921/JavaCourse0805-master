package day19_cyclicbarrier;

import java.util.ArrayList;
import java.util.List;

public class Exam {
    public static List<Integer> scores = new ArrayList<>();
}
