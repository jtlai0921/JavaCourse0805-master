package day07_2;

public class Phone extends Computer {
    public void call() {
        System.out.println("打電話");
    }
}
