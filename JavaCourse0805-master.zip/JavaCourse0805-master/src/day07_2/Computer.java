package day07_2;

public class Computer extends Machine {
    public void draw() {
        System.out.println("繪圖電腦");
    }
}
