package day07_2;

public class Machine {
    public void power() {
        System.out.println("吃電");
    }
}
