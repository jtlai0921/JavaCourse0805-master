package day02.casting;

public class Test {
    public static void main(String[] args) {
        float x = 2.5f;
        float y = (float)2.5;
        System.out.println(x);
        System.out.println(y);
        byte b = (byte)130;
        System.out.println(b);
        
    }
}
