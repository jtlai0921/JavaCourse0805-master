package day02.foo;

public class Coco {
    protected void play() {
        System.out.println("錢");
    }
}
