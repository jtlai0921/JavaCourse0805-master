package day02.foo;

public class David {
    public void play() {
        System.out.println("Magic");
        Coco coco = new Coco();
        coco.play();
    }
}
