package day07_3;

public class Machine {
 
	public void power() {
	}
	 
}
 
