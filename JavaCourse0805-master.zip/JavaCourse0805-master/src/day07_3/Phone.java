package day07_3;

public class Phone extends Machine {
 
	public void call() {
	}
	 
}
 
