package day07_3;

public class Computer extends Machine {
 
	public void draw() {
	}
	 
}
 
