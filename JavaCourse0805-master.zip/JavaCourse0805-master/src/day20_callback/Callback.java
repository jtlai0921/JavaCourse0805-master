package day20_callback;

public interface Callback {
    void setValue(Object value);
}
