package day10_lambda;

public interface IPuppy {
    void skill();
}
