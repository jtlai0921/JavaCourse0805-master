package day10_lambda;

public interface ICalc {
    int calc(int n, int m);
}
