package day20_observer;

public interface Observer {
    void update(String data);
}
