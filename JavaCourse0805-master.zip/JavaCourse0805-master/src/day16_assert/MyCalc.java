package day16_assert;

public class MyCalc {
    private int sum = 0;
    public void add(int x, int y) {
        sum = x + y;
    }

    public int getSum() {
        return sum;
    }
    
}
