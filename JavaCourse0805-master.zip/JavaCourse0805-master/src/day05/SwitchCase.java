package day05;

public class SwitchCase {
    public static void main(String[] args) {
        int x = 2;
        switch(x) {
            default:
                System.out.println("A");
            case 1:
                System.out.println("B");
        }
    }
}
