package day05;

public class CharTest {
    public static void main(String[] args) {
        int a = '巨';
        int b = '匠';
        System.out.println(a);
        System.out.println(b);
        char c = 24040;
        System.out.println(c);
        
        int x1 = '我';
        int x2 = '愛';
        int x3 = '你';
        System.out.println(x1+x2+x3);
    }
}
