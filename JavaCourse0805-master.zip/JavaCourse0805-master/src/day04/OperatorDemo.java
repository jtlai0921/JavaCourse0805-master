package day04;

public class OperatorDemo {
    public static void main(String[] args) {
        int x = 0;
        System.out.println(x++);
        System.out.println(x);
        
        int y = 0;
        y = y++;
        System.out.println(y);
        
    }
}
