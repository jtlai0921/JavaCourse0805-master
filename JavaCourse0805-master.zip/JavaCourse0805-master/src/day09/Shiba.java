package day09;

public class Shiba extends Animal {

    @Override
    public void play() {
        System.out.println("跳舞");
    }

}
