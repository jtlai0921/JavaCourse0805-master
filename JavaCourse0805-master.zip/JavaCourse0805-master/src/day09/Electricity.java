package day09;

public interface Electricity {
    int volt();
}
