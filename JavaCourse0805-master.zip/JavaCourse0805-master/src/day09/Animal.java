package day09;

public abstract class Animal implements IAnimal {

    @Override
    public void eat() {
        System.out.println("雞排");
    }
    
}
