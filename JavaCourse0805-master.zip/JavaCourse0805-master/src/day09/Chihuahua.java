package day09;

public class Chihuahua extends Animal {

    @Override
    public void play() {
        System.out.println("療鬱");
    }
    
}
