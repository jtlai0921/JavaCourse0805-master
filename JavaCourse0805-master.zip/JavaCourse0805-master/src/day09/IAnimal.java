package day09;

public interface IAnimal {
    int legs = 4;
    void play();
    void eat();
}
