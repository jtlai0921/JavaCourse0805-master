package day06_3;

public class Test {
    public static void main(String[] args) {
        MyClass t = new MyClass();
        System.out.println(t.i);
    }
}
