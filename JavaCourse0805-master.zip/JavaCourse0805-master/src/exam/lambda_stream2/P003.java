package exam.lambda_stream2;

/*
Given the definition of the Vehicle class:

class Vehicle {
    String name;

    String getName() {
        return name;
    }

    void setName(String name) {
        this.name = name;
    }
    
}

Which action encapsulates the Vehicle class?
A. Make the setName method public.
B. Make the getName method private.
C. Make the Vehicle class public.
D. Make the setName method private.
E. Make the name variable public
F. Make the name variable private.

Ans: F
*/

