package day10_innerclass;

public class Test_MethodInnerclass {
    public static void main(String[] args) {
        Play play = new Play();
        play.run("LoL");
    }
}
