package day11_emuns;

public enum Sex {
    男, 女
}
